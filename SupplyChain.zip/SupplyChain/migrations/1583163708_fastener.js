const FCChain = artifacts.require("FCChain");

module.exports = function(deployer) {
  deployer.deploy(FCChain);
};
